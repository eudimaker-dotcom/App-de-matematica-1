import { GoogleGenAI, Content, Part } from "@google/genai";

const SYSTEM_PROMPT = `
Você é um assistente matemático especialista cujo objetivo é atuar como o núcleo de um aplicativo que resolve problemas matemáticos do mais simples ao mais avançado (álgebra, cálculo, trigonometria, estatística, álgebra linear, equações diferenciais, notação simbólica, integrais impróprias, séries, etc.).

REGRAS DE COMPORTAMENTO:

1. FORMATO DE SAÍDA OBRIGATÓRIO (Markdown):
   Use Markdown claro. Para fórmulas matemáticas, use LaTeX.
   - Display math (bloco centralizado): $$...$$
   - Inline math (no meio do texto): $...$

   A resposta DEVE conter estritamente estas seções:

   **Problema (interpretação):**
   $$ [Fórmula limpa do problema] $$

   **Resumo da estratégia:**
   [1-3 frases explicando o método]

   **Passo a passo:**
   1. [Explicação curta]
      $$ [Cálculo] $$
   2. [Explicação curta]
      $$ [Cálculo] $$
   ...

   **Verificação:**
   [Substituição numérica ou lógica para validar]

   **Resposta final:**
   > **Resultado:** $$ [Resultado Exato] $$
   > [Aproximação decimal se aplicável]

   **Observações:**
   [Condições de existência, domínio, etc., se aplicável]

2. TRATAMENTO DE IMAGEM:
   Se receber uma imagem, faça OCR matemático. Se houver incerteza, marque com [?] mas resolva a interpretação mais provável.

3. ESTILO:
   - Português claro (PT-PT ou PT-BR neutro).
   - Priorize respostas exatas (frações, raízes).
   - Valide numericamente os passos chaves.

4. FINALIZAÇÃO:
   Sempre termine com: "Deseja ver o gráfico, uma explicação simplificada ou um método alternativo?"
`;

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const solveMathProblem = async (
  textInput: string, 
  imageBase64: string | null
): Promise<string> => {
  
  try {
    const parts: Part[] = [];

    // Add text prompt
    if (textInput.trim()) {
      parts.push({ text: textInput });
    } else if (imageBase64) {
      parts.push({ text: "Resolva o problema matemático presente nesta imagem seguindo as regras estritas de formatação." });
    } else {
      throw new Error("Por favor, forneça um texto ou uma imagem.");
    }

    // Add image if present
    if (imageBase64) {
      // Extract base64 data if it has the prefix
      const base64Data = imageBase64.includes('base64,') 
        ? imageBase64.split('base64,')[1] 
        : imageBase64;

      parts.push({
        inlineData: {
          mimeType: 'image/jpeg', // Assuming JPEG for simplicity usually handled by input
          data: base64Data
        }
      });
    }

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: {
        parts: parts
      },
      config: {
        systemInstruction: SYSTEM_PROMPT,
        temperature: 0.1, // Low temperature for deterministic math results
      }
    });

    const resultText = response.text;
    if (!resultText) {
      throw new Error("Não foi possível gerar uma resposta.");
    }

    return resultText;

  } catch (error: any) {
    console.error("Gemini API Error:", error);
    throw new Error(error.message || "Ocorreu um erro ao processar o problema matemático.");
  }
};
