import React from 'react';
import ReactMarkdown from 'react-markdown';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import { CheckCircle2, Download, Share2, Copy } from 'lucide-react';

interface OutputSectionProps {
  solution: string | null;
  error: string | null;
}

const OutputSection: React.FC<OutputSectionProps> = ({ solution, error }) => {
  if (error) {
    return (
      <div className="w-full bg-red-50 border border-red-200 rounded-2xl p-6 text-red-700">
        <h3 className="font-bold flex items-center space-x-2 mb-2">
          <span>Erro ao processar</span>
        </h3>
        <p>{error}</p>
      </div>
    );
  }

  if (!solution) {
    return (
      <div className="w-full h-64 md:h-96 bg-slate-100 rounded-2xl border-2 border-dashed border-slate-300 flex flex-col items-center justify-center text-slate-400 p-6 text-center">
        <div className="mb-4 bg-white p-4 rounded-full shadow-sm">
          <svg className="w-8 h-8 text-slate-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
          </svg>
        </div>
        <p className="font-medium">A solução aparecerá aqui</p>
        <p className="text-sm mt-2">Envie um problema de matemática para começar</p>
      </div>
    );
  }

  const copyToClipboard = () => {
    navigator.clipboard.writeText(solution);
    // Ideally allow a toast notification here
  };

  return (
    <div className="w-full bg-white rounded-2xl shadow-lg border border-slate-200 overflow-hidden">
      <div className="bg-slate-50 px-6 py-3 border-b border-slate-200 flex justify-between items-center">
        <div className="flex items-center space-x-2 text-green-700">
          <CheckCircle2 className="w-5 h-5" />
          <span className="font-semibold text-sm uppercase tracking-wide">Solução Gerada</span>
        </div>
        <div className="flex space-x-2">
          <button 
            onClick={copyToClipboard}
            className="p-2 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors" 
            title="Copiar LaTeX"
          >
            <Copy className="w-4 h-4" />
          </button>
          <button className="p-2 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors" title="Exportar">
            <Download className="w-4 h-4" />
          </button>
        </div>
      </div>
      
      <div className="p-6 md:p-8 overflow-x-auto">
        <div className="prose prose-slate max-w-none prose-headings:font-bold prose-h2:text-xl prose-h2:text-slate-800 prose-p:text-slate-600 prose-pre:bg-slate-900 prose-pre:text-slate-50">
          <ReactMarkdown
            children={solution}
            remarkPlugins={[remarkMath]}
            rehypePlugins={[rehypeKatex]}
            components={{
              // Custom rendering for specific markdown elements if needed
              p: ({node, ...props}) => <p className="mb-4 leading-relaxed text-base" {...props} />,
              blockquote: ({node, ...props}) => (
                <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded-r-lg my-6">
                  <blockquote className="not-italic text-slate-800 font-medium" {...props} />
                </div>
              ),
            }}
          />
        </div>
      </div>

      <div className="bg-slate-50 px-6 py-4 border-t border-slate-200 flex flex-wrap gap-3">
        <button className="px-4 py-2 bg-white border border-slate-300 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-50 hover:border-blue-400 transition-all shadow-sm">
          Explicação Simplificada
        </button>
        <button className="px-4 py-2 bg-white border border-slate-300 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-50 hover:border-blue-400 transition-all shadow-sm">
          Método Alternativo
        </button>
        <button className="px-4 py-2 bg-white border border-slate-300 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-50 hover:border-blue-400 transition-all shadow-sm">
          Ver Gráfico
        </button>
      </div>
    </div>
  );
};

export default OutputSection;
