import React, { useState, useRef } from 'react';
import { Camera, Upload, Send, X, Calculator } from 'lucide-react';

interface InputSectionProps {
  onSolve: (text: string, image: string | null) => void;
  isSolving: boolean;
}

const InputSection: React.FC<InputSectionProps> = ({ onSolve, isSolving }) => {
  const [text, setText] = useState('');
  const [image, setImage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text && !image) return;
    onSolve(text, image);
  };

  const clearImage = () => {
    setImage(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="w-full bg-white rounded-2xl shadow-lg p-4 md:p-6 border border-slate-200">
      <form onSubmit={handleSubmit} className="space-y-4">
        
        <div className="flex items-center space-x-2 mb-2 text-slate-600">
          <Calculator className="w-5 h-5 text-blue-600" />
          <h2 className="font-semibold">Insira seu problema</h2>
        </div>

        <div className="relative">
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Digite um problema (ex: Integre x^2 dx) ou cole LaTeX..."
            className="w-full min-h-[100px] p-4 pr-12 rounded-xl border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all resize-none font-mono text-sm md:text-base"
            disabled={isSolving}
          />
          {image && (
            <div className="absolute bottom-3 left-3 right-14 bg-slate-100 rounded-lg p-2 flex items-center justify-between border border-slate-200">
              <div className="flex items-center space-x-2 truncate">
                <span className="text-xs text-slate-500 font-medium bg-blue-100 text-blue-800 px-2 py-0.5 rounded">IMAGEM ANEXADA</span>
                <span className="text-xs text-slate-400 truncate max-w-[150px]">Imagem pronta para análise</span>
              </div>
              <button 
                type="button" 
                onClick={clearImage}
                className="p-1 hover:bg-slate-200 rounded-full transition-colors"
              >
                <X className="w-4 h-4 text-slate-500" />
              </button>
            </div>
          )}
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <input
              type="file"
              accept="image/*"
              className="hidden"
              ref={fileInputRef}
              onChange={handleFileChange}
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center space-x-2 px-4 py-2 text-sm font-medium text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
              disabled={isSolving}
            >
              <Camera className="w-4 h-4" />
              <span className="hidden sm:inline">Foto / Upload</span>
            </button>
          </div>

          <button
            type="submit"
            disabled={isSolving || (!text && !image)}
            className={`flex items-center space-x-2 px-6 py-2 rounded-lg font-semibold text-white transition-all transform active:scale-95 ${
              isSolving || (!text && !image)
                ? 'bg-slate-400 cursor-not-allowed'
                : 'bg-blue-600 hover:bg-blue-700 shadow-md hover:shadow-lg'
            }`}
          >
            {isSolving ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>Resolvendo...</span>
              </>
            ) : (
              <>
                <span>Resolver</span>
                <Send className="w-4 h-4" />
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};

export default InputSection;
